# Enhanced LLM Carbon RAG MVP

Features:
- FastAPI
- Qdrant vector store
- Carbon estimation
- Electricity Maps integration placeholder
- OpenAI answer generation placeholder
- Streamlit dashboard placeholder
- ESG report generator placeholder
