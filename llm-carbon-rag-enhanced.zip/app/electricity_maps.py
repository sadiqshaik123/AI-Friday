import requests

def get_carbon_intensity(region:str):
    # Replace with Electricity Maps API call
    return {'region': region, 'carbon_intensity': 300}
