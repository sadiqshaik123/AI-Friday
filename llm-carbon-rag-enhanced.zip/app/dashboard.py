# streamlit run app/dashboard.py
import streamlit as st
st.title('LLM Carbon Dashboard')
st.write('Connect APIs and display metrics here')
