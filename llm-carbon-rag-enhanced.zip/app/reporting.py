from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet

def generate_report(path='esg_report.pdf'):
    doc = SimpleDocTemplate(path)
    styles = getSampleStyleSheet()
    doc.build([Paragraph('ESG Carbon Report', styles['Title'])])
    return path
